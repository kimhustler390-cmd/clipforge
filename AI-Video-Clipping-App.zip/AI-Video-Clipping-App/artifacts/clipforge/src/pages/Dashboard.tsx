import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import {
  getGetDashboardSummaryQueryKey, getListProjectsQueryKey,
  useCreateProject, useDeleteProject, useGetDashboardSummary, useListProjects,
  useRequestUploadUrl, useConfirmProjectUpload,
} from '@workspace/api-client-react';
import type { Project } from '@workspace/api-client-react';
import WorkspaceShell from '@/components/WorkspaceShell';
import {
  ArrowDownRight, ArrowUpRight, Check, ChevronRight, CircleAlert, Clapperboard,
  FileVideo2, FolderPlus, LoaderCircle, Plus, RefreshCw, Upload, X,
} from 'lucide-react';
import { getVideoContentType, uploadVideoWithProgress } from '@/lib/uploadVideo';

function formatDate(value: string) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value));
}

function formatDuration(seconds: number | null) {
  if (seconds === null || !Number.isFinite(seconds)) return '—';
  const s = Math.floor(seconds);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function formatBytes(bytes: number | null) {
  if (bytes === null) return '—';
  return bytes >= 1_000_000_000 ? `${(bytes / 1_000_000_000).toFixed(1)} GB` : `${(bytes / 1_000_000).toFixed(0)} MB`;
}

function getErrorMessage(error: unknown) {
  if (error && typeof error === 'object' && 'message' in error) return String(error.message);
  return 'Something went wrong. Please try again.';
}

function ProjectStatus({ status }: { status: Project['status'] }) {
  const label = status === 'ready' ? 'Ready to edit' : status === 'failed' ? 'Upload failed' : status === 'inspecting' || status === 'processing' ? 'Inspecting source' : 'Awaiting upload';
  return <span className={`status-pill status-${status}`}><span className="status-dot" />{label}</span>;
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [isUploadOpen, setUploadOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [stage, setStage] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState('');
  const fileInput = useRef<HTMLInputElement>(null);
  const summaryQuery = useGetDashboardSummary({ request: { credentials: 'include' } });
  const projectsQuery = useListProjects({ request: { credentials: 'include' } });
  const createProject = useCreateProject({ request: { credentials: 'include' } });
  const deleteProject = useDeleteProject({ request: { credentials: 'include' } });
  const requestUploadUrl = useRequestUploadUrl({ request: { credentials: 'include' } });
  const confirmUpload = useConfirmProjectUpload({ request: { credentials: 'include' } });
  const projects = projectsQuery.data ?? [];
  const summary = summaryQuery.data;

  useEffect(() => {
    const open = () => { setUploadError(''); setUploadOpen(true); };
    window.addEventListener('clipforge:new-project', open);
    return () => window.removeEventListener('clipforge:new-project', open);
  }, []);

  function chooseFile(selected?: File) {
    if (!selected) return;
    if (!getVideoContentType(selected)) {
      setUploadError('Choose an MP4 or MOV video file.');
      return;
    }
    setFile(selected);
    setUploadError('');
    if (!title.trim()) setTitle(selected.name.replace(/\.[^/.]+$/, '').slice(0, 160));
  }

  async function handleUpload(event: FormEvent) {
    event.preventDefault();
    if (!file || !title.trim()) return;
    setUploadError('');
    let createdProjectId: string | null = null;
    try {
      setStage('Preparing secure upload');
      setUploadProgress(0);
      const contentType = getVideoContentType(file);
      if (!contentType) throw new Error('Choose an MP4 or MOV video file.');
      const signed = await requestUploadUrl.mutateAsync({
        data: { name: file.name, size: file.size, contentType },
      });
      setStage('Uploading source video');
      await uploadVideoWithProgress(signed.uploadURL, file, contentType, setUploadProgress);
      setStage('Creating project');
      const project = await createProject.mutateAsync({ data: { title: title.trim() } });
      createdProjectId = project.id;
      setStage('Confirming source');
      await confirmUpload.mutateAsync({
        projectId: project.id,
        data: {
          name: file.name, size: file.size, contentType,
          objectPath: signed.objectPath,
        },
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
      ]);
      setUploadOpen(false);
      setStage('');
      setUploadProgress(0);
      setTitle('');
      setFile(null);
      navigate(`/projects/${project.id}`);
    } catch (error) {
      if (createdProjectId) {
        try {
          await deleteProject.mutateAsync({ projectId: createdProjectId });
          await Promise.all([
            queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }),
            queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
          ]);
        } catch {
          // Preserve the upload error; the project remains available for recovery.
        }
      }
      setUploadError(getErrorMessage(error));
      setStage('');
      setUploadProgress(0);
    }
  }

  const isUploading = createProject.isPending || requestUploadUrl.isPending || confirmUpload.isPending || Boolean(stage);
  const projectsFailed = projectsQuery.isError;

  return (
    <WorkspaceShell>
      <div className="page-content dashboard-page">
        <header className="page-heading dashboard-heading">
          <div>
            <div className="eyebrow page-eyebrow"><span className="eyebrow-line" /> YOUR EDITING DESK</div>
            <h1>Projects<span className="heading-period">.</span></h1>
            <p className="page-subtitle">Bring the long cut in. Leave with the exact moment.</p>
          </div>
          <button className="button button-primary" onClick={() => { setUploadOpen(true); setUploadError(''); }} data-testid="button-new-project">
            <Plus size={17} /> New project
          </button>
        </header>

        <section className="metrics-row" aria-label="Workspace overview">
          <div className="metric-cell">
            <div className="metric-top"><span>PROJECTS</span><Clapperboard size={15} /></div>
            {summaryQuery.isLoading ? <div className="skeleton metric-skeleton" /> : <strong>{summary?.projectCount ?? '—'}</strong>}
            <small>Across your workspace</small>
          </div>
          <div className="metric-cell">
            <div className="metric-top"><span>READY TO EDIT</span><Check size={15} /></div>
            {summaryQuery.isLoading ? <div className="skeleton metric-skeleton" /> : <strong>{summary?.readyProjectCount ?? '—'}</strong>}
            <small>Sources inspected</small>
          </div>
          <div className="metric-cell">
            <div className="metric-top"><span>CLIPS EXPORTED</span><ArrowUpRight size={15} /></div>
            {summaryQuery.isLoading ? <div className="skeleton metric-skeleton" /> : <strong>{summary?.completedExportCount ?? '—'}</strong>}
            <small>{summary?.exportCount ?? 0} total render jobs</small>
          </div>
          <div className="metric-aside"><span className="metric-aside-kicker">THE WORKFLOW</span><span>One source.<br />One precise moment.</span><ArrowDownRight size={17} /></div>
        </section>

        <section className="project-section">
          <div className="section-heading">
            <div><div className="eyebrow section-eyebrow">LIBRARY</div><h2>Your source videos</h2></div>
            <span className="section-count">{projectsQuery.isLoading ? '—' : `${projects.length} ${projects.length === 1 ? 'project' : 'projects'}`}</span>
          </div>

          {summaryQuery.isError && (
            <div className="inline-alert" role="alert"><CircleAlert size={16} /><span>Workspace totals could not be loaded.</span>
              <button className="text-button" onClick={() => summaryQuery.refetch()} data-testid="button-retry-summary">Try again</button>
            </div>
          )}

          {projectsQuery.isLoading ? (
            <div className="project-list" aria-label="Loading projects">
              {[0, 1, 2].map((item) => <div className="project-skeleton" key={item}><div className="skeleton thumbnail-skeleton" /><div className="project-skeleton-lines"><div className="skeleton line-skeleton" /><div className="skeleton line-skeleton short" /></div><div className="skeleton pill-skeleton" /></div>)}
            </div>
          ) : projectsFailed ? (
            <div className="state-card state-error">
              <div className="state-icon error-icon"><CircleAlert size={19} /></div><h3>Projects didn’t load</h3>
              <p>{getErrorMessage(projectsQuery.error)}</p>
              <button className="button button-secondary" onClick={() => projectsQuery.refetch()} data-testid="button-retry-projects"><RefreshCw size={15} /> Retry</button>
            </div>
          ) : projects.length === 0 ? (
            <div className="empty-library">
              <div className="empty-art"><div className="empty-frame"><FileVideo2 size={30} /><span className="empty-play" /></div><div className="empty-orbit orbit-one" /><div className="empty-orbit orbit-two" /></div>
              <div className="empty-copy">
                <div className="eyebrow">A CLEAN TIMELINE AWAITS</div>
                <h3>Start with the source.</h3>
                <p>Upload a video to create your first editing project. Your source stays attached to the project; your cuts stay yours.</p>
                <button className="button button-primary" onClick={() => setUploadOpen(true)} data-testid="button-empty-upload"><Upload size={16} /> Upload a video</button>
              </div>
              <div className="empty-index"><span>01</span><i /><span>01</span></div>
            </div>
          ) : (
            <div className="project-list">
              <div className="list-header"><span>PROJECT</span><span>SOURCE</span><span>DURATION</span><span>STATUS</span><span>CREATED</span><span /></div>
              {projects.map((project) => (
                <Link href={`/projects/${project.id}`} className="project-row" key={project.id} data-testid={`link-project-${project.id}`}>
                  <div className="project-name-cell"><div className="project-tile"><FileVideo2 size={18} /></div><div className="project-title-stack"><strong>{project.title}</strong><span>{project.sourceWidth && project.sourceHeight ? `${project.sourceWidth} × ${project.sourceHeight}` : 'Source dimensions pending'}</span></div></div>
                  <span className="file-cell" title={project.sourceFilename ?? undefined}>{project.sourceFilename || 'No source uploaded'}</span>
                  <span className="mono-cell">{formatDuration(project.sourceDuration)}</span>
                  <span><ProjectStatus status={project.status} /></span>
                  <span className="date-cell">{formatDate(project.createdAt)}</span>
                  <ChevronRight className="row-chevron" size={16} />
                </Link>
              ))}
            </div>
          )}
          <div className="list-footnote"><span className="live-dot" /> Project and export data syncs with your account</div>
        </section>
      </div>

      {isUploadOpen && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !isUploading) setUploadOpen(false); }}>
          <section className="upload-modal" role="dialog" aria-modal="true" aria-labelledby="upload-modal-title">
            <header className="modal-header"><div><div className="eyebrow">NEW WORKSPACE</div><h2 id="upload-modal-title">Create a project</h2></div><button className="icon-button" aria-label="Close dialog" disabled={isUploading} onClick={() => setUploadOpen(false)} data-testid="button-close-upload"><X size={18} /></button></header>
            <form onSubmit={handleUpload}>
              <label className="field-label" htmlFor="project-title">Project name</label>
              <input id="project-title" className="text-input" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Name this edit" maxLength={160} required disabled={isUploading} data-testid="input-project-title" />
              <span className="field-hint">A clear name makes every version easier to find.</span>
              <input ref={fileInput} className="visually-hidden" type="file" accept="video/mp4,video/quicktime,.mp4,.mov" onChange={(event) => chooseFile(event.target.files?.[0])} disabled={isUploading} data-testid="input-video-file" />
              <button type="button" className={`dropzone ${dragging ? 'dropzone-active' : ''} ${file ? 'dropzone-has-file' : ''}`} onClick={() => fileInput.current?.click()} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files[0]); }} disabled={isUploading} data-testid="button-select-video">
                <span className="upload-mark">{file ? <Check size={18} /> : <Upload size={18} />}</span>
                <strong>{file ? file.name : 'Drop a video file here'}</strong>
                <small>{file ? `${formatBytes(file.size)} · ready to upload` : 'or browse your files · MP4, MOV'}</small>
              </button>
              {uploadError && <div className="form-error" role="alert"><CircleAlert size={15} />{uploadError}</div>}
              {isUploading && <div className="upload-stage"><LoaderCircle size={15} className="spin" /><span>{stage || 'Working…'}</span>{stage === 'Uploading source video' && <span className="upload-stage-percent">{uploadProgress}%</span>}<span className="upload-stage-caption">Keep this window open</span>{stage === 'Uploading source video' && <div className="upload-progress-track"><span style={{ width: `${uploadProgress}%` }} /></div>}</div>}
              <footer className="modal-footer">
                <button type="button" className="button button-quiet" onClick={() => setUploadOpen(false)} disabled={isUploading} data-testid="button-cancel-upload">Cancel</button>
                <button type="submit" className="button button-primary" disabled={!file || !title.trim() || isUploading} data-testid="button-create-upload">
                  {isUploading ? <><LoaderCircle size={15} className="spin" /> Working</> : <><FolderPlus size={16} /> Create and upload</>}
                </button>
              </footer>
            </form>
          </section>
        </div>
      )}
    </WorkspaceShell>
  );
}
