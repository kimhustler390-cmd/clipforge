import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
  doublePrecision,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";
import { projectsTable } from "./projects";

export const exportsTable = pgTable(
  "video_exports",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projectsTable.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    startTime: doublePrecision("start_time").notNull(),
    endTime: doublePrecision("end_time").notNull(),
    aspectRatio: varchar("aspect_ratio", { length: 8 }).notNull(),
    status: varchar("status", { length: 32 }).notNull().default("queued"),
    progress: integer("progress").notNull().default(0),
    outputObjectPath: text("output_object_path"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("video_exports_project_created_idx").on(table.projectId, table.createdAt),
    index("video_exports_user_status_idx").on(table.userId, table.status),
  ],
);

export type VideoExport = typeof exportsTable.$inferSelect;
export type InsertVideoExport = typeof exportsTable.$inferInsert;
