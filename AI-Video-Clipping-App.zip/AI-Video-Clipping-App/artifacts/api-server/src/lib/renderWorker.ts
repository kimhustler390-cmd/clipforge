import { createReadStream } from "node:fs";
import { mkdtemp, rm, stat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { pipeline } from "node:stream/promises";
import { and, asc, eq } from "drizzle-orm";
import { db, exportsTable, projectsTable } from "@workspace/db";
import { logger } from "./logger";
import {
  ObjectStorageService,
  objectStorageClient,
} from "./objectStorage";
import {
  getMaxSourceDurationSeconds,
  probeVideoFile,
} from "./videoProcessing";

const storage = new ObjectStorageService();
let workerStarted = false;

function outputDimensions(aspectRatio: string): { width: number; height: number } {
  switch (aspectRatio) {
    case "9:16":
      return { width: 1080, height: 1920 };
    case "1:1":
      return { width: 1080, height: 1080 };
    case "4:5":
      return { width: 1080, height: 1350 };
    default:
      return { width: 1920, height: 1080 };
  }
}

function getOutputObjectLocation(exportId: string) {
  const privateDir = storage.getPrivateObjectDir().replace(/\/+$/, "");
  const parts = privateDir.split("/").filter(Boolean);
  const bucketName = parts.shift();
  if (!bucketName) {
    throw new Error("Private object storage path is invalid.");
  }
  const filename = `clip-${exportId}.mp4`;
  const objectName = [...parts, "exports", filename].join("/");
  return {
    bucketName,
    objectName,
    objectPath: `/objects/exports/${filename}`,
    filename,
  };
}

function updateRenderProgress(exportId: string, progress: number): void {
  void db
    .update(exportsTable)
    .set({ progress, updatedAt: new Date() })
    .where(
      and(
        eq(exportsTable.id, exportId),
        eq(exportsTable.status, "processing"),
      ),
    )
    .catch((err: unknown) => {
      logger.warn({ err, exportId }, "Could not persist render progress");
    });
}

function runFfmpeg(
  args: string[],
  duration: number,
  exportId: string,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdoutBuffer = "";
    let stderrTail = "";
    let lastProgress = 1;

    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      stdoutBuffer += chunk;
      const lines = stdoutBuffer.split(/\r?\n/);
      stdoutBuffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("out_time_ms=")) continue;
        const outTimeMicroseconds = Number(line.slice("out_time_ms=".length));
        if (!Number.isFinite(outTimeMicroseconds)) continue;
        const progress = Math.min(
          95,
          Math.max(
            1,
            Math.floor((outTimeMicroseconds / (duration * 1_000_000)) * 95),
          ),
        );
        if (progress >= lastProgress + 2) {
          lastProgress = progress;
          updateRenderProgress(exportId, progress);
        }
      }
    });
    child.stderr.on("data", (chunk: string) => {
      stderrTail = `${stderrTail}${chunk}`.slice(-4000);
    });
    child.once("error", reject);
    child.once("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg exited with code ${code}: ${stderrTail}`));
      }
    });
  });
}

async function renderExport(exportId: string): Promise<void> {
  const [videoExport] = await db
    .select()
    .from(exportsTable)
    .where(eq(exportsTable.id, exportId))
    .limit(1);
  if (!videoExport) return;

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, videoExport.projectId))
    .limit(1);
  if (!project?.sourceObjectPath) {
    throw new Error("Source video is no longer attached to this project.");
  }

  const tempDir = await mkdtemp(path.join(os.tmpdir(), "clipforge-"));
  const sourcePath = path.join(tempDir, "source-video");
  const outputPath = path.join(tempDir, "clip.mp4");
  let uploadedObjectPath: string | undefined;
  let exportSaved = false;

  try {
    const sourceFile = await storage.getObjectEntityFile(
      project.sourceObjectPath,
    );
    await sourceFile.download({ destination: sourcePath });

    const dimensions = outputDimensions(videoExport.aspectRatio);
    const filters =
      videoExport.aspectRatio === "16:9"
        ? `scale=${dimensions.width}:${dimensions.height}:force_original_aspect_ratio=decrease,pad=${dimensions.width}:${dimensions.height}:(ow-iw)/2:(oh-ih)/2`
        : `scale=${dimensions.width}:${dimensions.height}:force_original_aspect_ratio=increase,crop=${dimensions.width}:${dimensions.height}`;
    const duration = videoExport.endTime - videoExport.startTime;
    const args = [
      "-y",
      "-i",
      sourcePath,
      "-ss",
      String(videoExport.startTime),
      "-t",
      String(duration),
      "-map",
      "0:v:0",
      "-map",
      "0:a?",
      "-vf",
      filters,
      "-c:v",
      "libx264",
      "-preset",
      "veryfast",
      "-crf",
      "22",
      "-pix_fmt",
      "yuv420p",
      "-c:a",
      "aac",
      "-b:a",
      "160k",
      "-movflags",
      "+faststart",
      "-progress",
      "pipe:1",
      "-nostats",
      outputPath,
    ];
    await runFfmpeg(args, duration, exportId);

    const outputStat = await stat(outputPath);
    if (!outputStat.isFile() || outputStat.size === 0) {
      throw new Error("FFmpeg produced an empty output file.");
    }
    const renderedMetadata = await probeVideoFile(outputPath);
    if (
      renderedMetadata.duration <= 0 ||
      renderedMetadata.width !== dimensions.width ||
      renderedMetadata.height !== dimensions.height
    ) {
      throw new Error("The rendered video did not match the selected format.");
    }

    const location = getOutputObjectLocation(exportId);
    uploadedObjectPath = location.objectPath;
    const outputFile = objectStorageClient
      .bucket(location.bucketName)
      .file(location.objectName);
    await pipeline(
      createReadStream(outputPath),
      outputFile.createWriteStream({
        resumable: false,
        metadata: {
          contentType: "video/mp4",
          contentDisposition: `attachment; filename="${location.filename}"`,
        },
      }),
    );
    await storage.trySetObjectEntityAclPolicy(location.objectPath, {
      owner: videoExport.userId,
      visibility: "private",
    });
    const [completedExport] = await db
      .update(exportsTable)
      .set({
        status: "completed",
        progress: 100,
        outputObjectPath: location.objectPath,
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(exportsTable.id, exportId),
          eq(exportsTable.status, "processing"),
        ),
      )
      .returning({ id: exportsTable.id });
    if (!completedExport) {
      throw new Error("The export job was removed before completion.");
    }
    exportSaved = true;
  } finally {
    if (uploadedObjectPath && !exportSaved) {
      try {
        const outputFile = await storage.getObjectEntityFile(uploadedObjectPath);
        await outputFile.delete({ ignoreNotFound: true });
      } catch {
        // The failed render will remain marked for retry even if cleanup is delayed.
      }
    }
    await rm(tempDir, { recursive: true, force: true });
  }
}

async function inspectProjectSource(projectId: string): Promise<void> {
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId))
    .limit(1);
  if (!project?.sourceObjectPath) {
    throw new Error("Source video is no longer attached to this project.");
  }

  let tempDir: string;
  try {
    tempDir = await mkdtemp(path.join(os.tmpdir(), "clipforge-inspect-"));
  } catch (err) {
    logger.error({ err, projectId }, "Could not allocate source inspection space");
    await db
      .update(projectsTable)
      .set({
        status: "failed",
        errorMessage: "The source video could not be inspected. Try uploading it again.",
        updatedAt: new Date(),
      })
      .where(eq(projectsTable.id, projectId));
    return;
  }
  const sourcePath = path.join(tempDir, "source-video");
  try {
    const sourceFile = await storage.getObjectEntityFile(
      project.sourceObjectPath,
    );
    await sourceFile.download({ destination: sourcePath });
    const metadata = await probeVideoFile(sourcePath);
    if (metadata.duration > getMaxSourceDurationSeconds()) {
      throw new Error("Source exceeds the configured maximum duration.");
    }
    await db
      .update(projectsTable)
      .set({
        status: "ready",
        sourceDuration: metadata.duration,
        sourceWidth: metadata.width,
        sourceHeight: metadata.height,
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(eq(projectsTable.id, projectId));
  } catch (err) {
    logger.error({ err, projectId }, "Source video inspection failed");
    await db
      .update(projectsTable)
      .set({
        status: "failed",
        errorMessage:
          err instanceof Error &&
          err.message === "Source exceeds the configured maximum duration."
            ? "This source video is longer than the configured limit."
            : "The video could not be inspected. Use a valid MP4 or MOV file.",
        updatedAt: new Date(),
      })
      .where(eq(projectsTable.id, projectId));
  } finally {
    await rm(tempDir, { recursive: true, force: true });
  }
}

async function processClaimedExport(exportId: string): Promise<void> {
  try {
    await renderExport(exportId);
  } catch (err) {
    logger.error({ err, exportId }, "Video export failed");
    await db
      .update(exportsTable)
      .set({
        status: "failed",
        errorMessage:
          "The clip could not be rendered. Check the source and try again.",
        updatedAt: new Date(),
      })
      .where(eq(exportsTable.id, exportId));
  }
}

async function pollQueue(): Promise<void> {
  try {
    const [projectCandidate] = await db
      .select({ id: projectsTable.id })
      .from(projectsTable)
      .where(eq(projectsTable.status, "inspecting"))
      .orderBy(asc(projectsTable.createdAt))
      .limit(1);
    if (projectCandidate) {
      const [claimedProject] = await db
        .update(projectsTable)
        .set({ status: "processing", updatedAt: new Date() })
        .where(
          and(
            eq(projectsTable.id, projectCandidate.id),
            eq(projectsTable.status, "inspecting"),
          ),
        )
        .returning({ id: projectsTable.id });
      if (claimedProject) {
        await inspectProjectSource(claimedProject.id);
        setTimeout(() => void pollQueue(), 0);
        return;
      }
    }

    const [candidate] = await db
      .select({ id: exportsTable.id })
      .from(exportsTable)
      .where(eq(exportsTable.status, "queued"))
      .orderBy(asc(exportsTable.createdAt))
      .limit(1);
    if (!candidate) {
      setTimeout(() => void pollQueue(), 1200);
      return;
    }

    const [claimed] = await db
      .update(exportsTable)
      .set({ status: "processing", progress: 1, updatedAt: new Date() })
      .where(
        and(
          eq(exportsTable.id, candidate.id),
          eq(exportsTable.status, "queued"),
        ),
      )
      .returning({ id: exportsTable.id });
    if (claimed) {
      await processClaimedExport(claimed.id);
    }
  } catch (err) {
    logger.error({ err }, "Render queue polling failed");
  }
  setTimeout(() => void pollQueue(), 300);
}

export function startRenderWorker(): void {
  if (workerStarted) return;
  workerStarted = true;
  void Promise.all([
    db
      .update(exportsTable)
      .set({ status: "queued", progress: 0, updatedAt: new Date() })
      .where(eq(exportsTable.status, "processing")),
    db
      .update(projectsTable)
      .set({ status: "inspecting", updatedAt: new Date() })
      .where(eq(projectsTable.status, "processing")),
  ])
    .then(() => {
      void pollQueue();
    })
    .catch((err: unknown) => {
      logger.error({ err }, "Could not recover interrupted render jobs");
      void pollQueue();
    });
}
