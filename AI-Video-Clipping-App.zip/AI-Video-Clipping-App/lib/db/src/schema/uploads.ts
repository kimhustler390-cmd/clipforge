import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";
import { projectsTable } from "./projects";

export const videoUploadsTable = pgTable(
  "video_uploads",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: varchar("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").references(() => projectsTable.id, {
      onDelete: "cascade",
    }),
    objectPath: text("object_path").notNull().unique(),
    originalName: varchar("original_name", { length: 255 }).notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    contentType: varchar("content_type", { length: 128 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
  },
  (table) => [index("video_uploads_user_created_idx").on(table.userId, table.createdAt)],
);

export type VideoUpload = typeof videoUploadsTable.$inferSelect;
