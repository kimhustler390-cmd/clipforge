import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export interface VideoMetadata {
  duration: number;
  width: number;
  height: number;
}

export function isSupportedVideo(name: string, contentType: string): boolean {
  const extension = name.split(".").pop()?.toLowerCase();
  return (
    (extension === "mp4" && contentType === "video/mp4") ||
    (extension === "mov" && contentType === "video/quicktime")
  );
}

export function getMaxSourceDurationSeconds(): number {
  const value = Number(process.env.MAX_SOURCE_DURATION_SECONDS ?? 7200);
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error("MAX_SOURCE_DURATION_SECONDS must be a positive number.");
  }
  return value;
}

export function getMaxClipDurationSeconds(): number {
  const value = Number(process.env.MAX_CLIP_DURATION_SECONDS ?? 180);
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error("MAX_CLIP_DURATION_SECONDS must be a positive number.");
  }
  return value;
}

export async function probeVideoFile(filePath: string): Promise<VideoMetadata> {
  const { stdout } = await execFileAsync(
    "ffprobe",
    [
      "-v",
      "error",
      "-show_entries",
      "format=duration:stream=codec_type,width,height,duration",
      "-of",
      "json",
      filePath,
    ],
    { timeout: 120_000, maxBuffer: 2 * 1024 * 1024 },
  );
  const result = JSON.parse(stdout.toString()) as {
    format?: { duration?: string };
    streams?: Array<{
      codec_type?: string;
      width?: number;
      height?: number;
      duration?: string;
    }>;
  };
  const videoStream = result.streams?.find(
    (stream) => stream.codec_type === "video",
  );
  const duration = Number(result.format?.duration ?? videoStream?.duration);
  const width = Number(videoStream?.width);
  const height = Number(videoStream?.height);

  if (
    !videoStream ||
    !Number.isFinite(duration) ||
    duration <= 0 ||
    !Number.isInteger(width) ||
    !Number.isInteger(height) ||
    width <= 0 ||
    height <= 0
  ) {
    throw new Error("The uploaded file does not contain a valid video stream.");
  }

  return { duration, width, height };
}
