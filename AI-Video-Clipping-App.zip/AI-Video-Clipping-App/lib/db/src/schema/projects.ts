import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
  doublePrecision,
} from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const projectsTable = pgTable(
  "video_projects",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: varchar("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 160 }).notNull(),
    status: varchar("status", { length: 32 }).notNull().default("awaiting_upload"),
    sourceFilename: varchar("source_filename", { length: 255 }),
    sourceObjectPath: text("source_object_path"),
    sourceSizeBytes: integer("source_size_bytes"),
    sourceDuration: doublePrecision("source_duration"),
    sourceWidth: integer("source_width"),
    sourceHeight: integer("source_height"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("video_projects_user_updated_idx").on(table.userId, table.updatedAt),
  ],
);

export type VideoProject = typeof projectsTable.$inferSelect;
export type InsertVideoProject = typeof projectsTable.$inferInsert;
