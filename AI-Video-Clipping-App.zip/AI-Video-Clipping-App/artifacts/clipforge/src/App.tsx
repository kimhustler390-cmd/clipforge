import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Dashboard from '@/pages/Dashboard';
import ProjectWorkspace from '@/pages/ProjectWorkspace';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { useAuth } from '@workspace/replit-auth-web';
import { Film, LogIn } from 'lucide-react';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 15_000, refetchOnWindowFocus: true } },
});

function AuthGate({ children }: { children: ReactNode }) {
  const { user, isLoading, isAuthenticated, login } = useAuth();

  if (isLoading) {
    return (
      <main className="auth-state">
        <div className="auth-mark"><Film size={22} /></div>
        <div className="skeleton auth-skeleton" />
        <div className="skeleton auth-skeleton short" />
        <span className="sr-only">Checking your session…</span>
      </main>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <main className="auth-state">
        <div className="auth-mark"><Film size={22} /></div>
        <p className="eyebrow">CLIPFORGE / CREATOR WORKSPACE</p>
        <h1>Your next cut starts here.</h1>
        <p className="auth-copy">Sign in to work with your source videos, shape a precise clip, and keep every export in one place.</p>
        <button className="button button-primary" onClick={login} data-testid="button-login">
          <LogIn size={16} /> Continue to Clipforge
        </button>
        <span className="auth-note">Your projects are private to your account.</span>
      </main>
    );
  }

  return <>{children}</>;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <AuthGate>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/projects/:projectId" component={ProjectWorkspace} />
          <Route component={NotFound} />
        </Switch>
      </AuthGate>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
