import { Link, useLocation } from 'wouter';
import { Film, FolderOpen, LogOut, Plus, Settings2 } from 'lucide-react';
import { useAuth } from '@workspace/replit-auth-web';
import type { ReactNode } from 'react';

export default function WorkspaceShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const name = [user?.firstName, user?.lastName].filter(Boolean).join(' ') || user?.email || 'Creator';
  const initials = name.split(/[\s@.]/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase();

  return (
    <div className="app-frame">
      <aside className="sidebar">
        <Link href="/" className="brand" data-testid="link-brand">
          <span className="brand-icon"><Film size={18} strokeWidth={2.4} /></span>
          <span>clipforge<span className="brand-period">.</span></span>
        </Link>
        <div className="sidebar-label">WORKSPACE</div>
        <nav className="side-nav" aria-label="Workspace navigation">
          <Link href="/" className={`side-link ${location === '/' ? 'active' : ''}`} data-testid="link-projects">
            <FolderOpen size={17} /> <span>Projects</span>
          </Link>
          <button className="side-link side-action" onClick={() => window.dispatchEvent(new Event('clipforge:new-project'))} data-testid="button-sidebar-new">
            <Plus size={17} /> <span>New project</span>
          </button>
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-bottom">
          <div className="sidebar-note">
            <span className="live-dot" />
            <span>LOCAL WORKSPACE</span>
          </div>
          <div className="profile-row">
            <div className="avatar">{initials || 'C'}</div>
            <div className="profile-info">
              <strong>{name}</strong>
              <span>Creator account</span>
            </div>
            <button className="icon-button logout-button" aria-label="Log out" title="Log out" onClick={logout} data-testid="button-logout">
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>
      <main className="main-area">
        <div className="mobile-topbar">
          <Link href="/" className="brand" data-testid="link-mobile-brand">
            <span className="brand-icon"><Film size={17} /></span><span>clipforge<span className="brand-period">.</span></span>
          </Link>
          <button className="icon-button" aria-label="Log out" onClick={logout} data-testid="button-mobile-logout"><LogOut size={16} /></button>
        </div>
        {children}
        <footer className="app-footer"><span>CLIPFORGE</span><span>Precise cuts. Your call.</span><Settings2 size={13} /></footer>
      </main>
    </div>
  );
}
