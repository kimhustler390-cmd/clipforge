import {
  ConfirmProjectUploadBody,
  ConfirmProjectUploadParams,
  ConfirmProjectUploadResponse,
  CreateProjectBody,
  CreateProjectResponse,
  CreateProjectExportBody,
  CreateProjectExportParams,
  CreateProjectExportResponse,
  DeleteProjectParams,
  DownloadExportParams,
  GetDashboardSummaryResponse,
  GetExportParams,
  GetExportResponse,
  GetProjectParams,
  GetProjectResponse,
  GetProjectSourceParams,
  ListProjectExportsParams,
  ListProjectExportsResponse,
  ListProjectsResponse,
  UpdateProjectBody,
  UpdateProjectParams,
  UpdateProjectResponse,
} from "@workspace/api-zod";
import {
  db,
  exportsTable,
  projectsTable,
  videoUploadsTable,
} from "@workspace/db";
import { and, count, desc, eq, ne } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import { basename } from "node:path";
import { ObjectPermission } from "../lib/objectAcl";
import {
  ObjectNotFoundError,
  ObjectStorageService,
} from "../lib/objectStorage";
import {
  getMaxClipDurationSeconds,
  isSupportedVideo,
} from "../lib/videoProcessing";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const maxUploadBytes = Number(
  process.env.MAX_VIDEO_UPLOAD_BYTES ?? 1_000_000_000,
);

if (!Number.isSafeInteger(maxUploadBytes) || maxUploadBytes < 1) {
  throw new Error("MAX_VIDEO_UPLOAD_BYTES must be a positive integer.");
}

function requireUserId(req: Request, res: Response): string | null {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Sign in to access your video projects." });
    return null;
  }
  return req.user.id;
}

function projectResponse(project: typeof projectsTable.$inferSelect) {
  return {
    id: project.id,
    title: project.title,
    status: project.status,
    sourceFilename: project.sourceFilename,
    sourceSizeBytes: project.sourceSizeBytes,
    sourceDuration: project.sourceDuration,
    sourceWidth: project.sourceWidth,
    sourceHeight: project.sourceHeight,
    sourcePlaybackUrl: project.sourceObjectPath
      ? `/api/projects/${project.id}/source`
      : null,
    errorMessage: project.errorMessage,
    createdAt: project.createdAt.toISOString(),
    updatedAt: project.updatedAt.toISOString(),
  };
}

function exportResponse(videoExport: typeof exportsTable.$inferSelect) {
  return {
    id: videoExport.id,
    projectId: videoExport.projectId,
    startTime: videoExport.startTime,
    endTime: videoExport.endTime,
    aspectRatio: videoExport.aspectRatio,
    status: videoExport.status,
    progress: videoExport.progress,
    errorMessage: videoExport.errorMessage,
    createdAt: videoExport.createdAt.toISOString(),
    updatedAt: videoExport.updatedAt.toISOString(),
  };
}

function parseRange(value: string, size: number) {
  const match = /^bytes=(\d*)-(\d*)$/.exec(value);
  if (!match || (!match[1] && !match[2])) return null;
  let start: number;
  let end: number;
  if (!match[1]) {
    const suffixLength = Number(match[2]);
    if (!Number.isSafeInteger(suffixLength) || suffixLength < 1) return null;
    start = Math.max(0, size - suffixLength);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Number(match[2]) : size - 1;
  }
  if (
    !Number.isSafeInteger(start) ||
    !Number.isSafeInteger(end) ||
    start < 0 ||
    end < start ||
    start >= size
  ) {
    return null;
  }
  return { start, end: Math.min(end, size - 1) };
}

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;

  const [projectTotals] = await db
    .select({ total: count() })
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId));
  const [readyTotals] = await db
    .select({ total: count() })
    .from(projectsTable)
    .where(
      and(
        eq(projectsTable.userId, userId),
        eq(projectsTable.status, "ready"),
      ),
    );
  const [exportTotals] = await db
    .select({ total: count() })
    .from(exportsTable)
    .where(eq(exportsTable.userId, userId));
  const [completedTotals] = await db
    .select({ total: count() })
    .from(exportsTable)
    .where(
      and(
        eq(exportsTable.userId, userId),
        eq(exportsTable.status, "completed"),
      ),
    );
  const recentProjects = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId))
    .orderBy(desc(projectsTable.updatedAt))
    .limit(5);

  res.json(
    GetDashboardSummaryResponse.parse({
      projectCount: projectTotals.total,
      readyProjectCount: readyTotals.total,
      exportCount: exportTotals.total,
      completedExportCount: completedTotals.total,
      recentProjects: recentProjects.map(projectResponse),
    }),
  );
});

router.get("/projects", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;

  const projects = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.userId, userId))
    .orderBy(desc(projectsTable.updatedAt));
  res.json(ListProjectsResponse.parse(projects.map(projectResponse)));
});

router.post("/projects", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a project name up to 160 characters." });
    return;
  }

  const [project] = await db
    .insert(projectsTable)
    .values({ userId, title: parsed.data.title.trim() })
    .returning();
  res
    .status(201)
    .json(CreateProjectResponse.parse(projectResponse(project)));
});

router.get("/projects/:projectId", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = GetProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid project id." });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(
      and(
        eq(projectsTable.id, params.data.projectId),
        eq(projectsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!project) {
    res.status(404).json({ error: "Project not found." });
    return;
  }
  res.json(GetProjectResponse.parse(projectResponse(project)));
});

router.patch("/projects/:projectId", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = UpdateProjectParams.safeParse(req.params);
  const body = UpdateProjectBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Enter a project name up to 160 characters." });
    return;
  }

  const [project] = await db
    .update(projectsTable)
    .set({ title: body.data.title.trim(), updatedAt: new Date() })
    .where(
      and(
        eq(projectsTable.id, params.data.projectId),
        eq(projectsTable.userId, userId),
      ),
    )
    .returning();
  if (!project) {
    res.status(404).json({ error: "Project not found." });
    return;
  }
  res.json(UpdateProjectResponse.parse(projectResponse(project)));
});

router.delete("/projects/:projectId", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = DeleteProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid project id." });
    return;
  }
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(
      and(
        eq(projectsTable.id, params.data.projectId),
        eq(projectsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!project) {
    res.status(404).json({ error: "Project not found." });
    return;
  }

  const exports = await db
    .select()
    .from(exportsTable)
    .where(
      and(
        eq(exportsTable.projectId, project.id),
        eq(exportsTable.userId, userId),
      ),
    );
  try {
    const paths = [
      project.sourceObjectPath,
      ...exports.map((item) => item.outputObjectPath),
    ].filter((value): value is string => Boolean(value));
    for (const objectPath of paths) {
      const file = await storage.getObjectEntityFile(objectPath);
      await file.delete({ ignoreNotFound: true });
    }
  } catch (err) {
    req.log.error({ err, projectId: project.id }, "Could not delete project files");
    res.status(500).json({ error: "Could not remove project files. Please retry." });
    return;
  }

  await db
    .delete(projectsTable)
    .where(
      and(
        eq(projectsTable.id, project.id),
        eq(projectsTable.userId, userId),
      ),
    );
  res.sendStatus(204);
});

router.post(
  "/projects/:projectId/confirm-upload",
  async (req, res): Promise<void> => {
    const userId = requireUserId(req, res);
    if (!userId) return;
    const params = ConfirmProjectUploadParams.safeParse(req.params);
    const body = ConfirmProjectUploadBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({ error: "Upload details are incomplete." });
      return;
    }

    const [project] = await db
      .select()
      .from(projectsTable)
      .where(
        and(
          eq(projectsTable.id, params.data.projectId),
          eq(projectsTable.userId, userId),
        ),
      )
      .limit(1);
    if (!project) {
      res.status(404).json({ error: "Project not found." });
      return;
    }

    const [upload] = await db
      .select()
      .from(videoUploadsTable)
      .where(
        and(
          eq(videoUploadsTable.objectPath, body.data.objectPath),
          eq(videoUploadsTable.userId, userId),
        ),
      )
      .limit(1);
    if (
      !upload ||
      (upload.projectId !== null && upload.projectId !== project.id) ||
      upload.originalName !== body.data.name ||
      upload.sizeBytes !== body.data.size ||
      upload.contentType !== body.data.contentType
    ) {
      res.status(404).json({ error: "Uploaded video not found." });
      return;
    }
    if (upload.projectId === project.id && project.sourceObjectPath === upload.objectPath) {
      res.json(ConfirmProjectUploadResponse.parse(projectResponse(project)));
      return;
    }
    if (!isSupportedVideo(upload.originalName, upload.contentType)) {
      res.status(400).json({ error: "Choose an MP4 or MOV video file." });
      return;
    }
    if (upload.sizeBytes > maxUploadBytes) {
      res.status(400).json({
        error: `This file exceeds the ${Math.floor(maxUploadBytes / 1_000_000)} MB upload limit.`,
      });
      return;
    }

    let actualSize: number;
    try {
      const sourceFile = await storage.getObjectEntityFile(upload.objectPath);
      const [objectMetadata] = await sourceFile.getMetadata();
      actualSize = Number(objectMetadata.size);
      const actualContentType = String(
        objectMetadata.contentType ?? upload.contentType,
      );
      if (
        !Number.isSafeInteger(actualSize) ||
        actualSize !== upload.sizeBytes ||
        actualSize > maxUploadBytes ||
        !isSupportedVideo(upload.originalName, actualContentType)
      ) {
        throw new Error("Uploaded video metadata does not match the request.");
      }
      await storage.trySetObjectEntityAclPolicy(upload.objectPath, {
        owner: userId,
        visibility: "private",
      });
    } catch (err) {
      req.log.warn({ err, projectId: project.id }, "Source upload confirmation failed");
      res.status(400).json({
        error: "The uploaded video is not ready or does not match its file details.",
      });
      return;
    }

    const [updated] = await db.transaction(async (tx) => {
      const [updatedProject] = await tx
        .update(projectsTable)
        .set({
          status: "inspecting",
          sourceFilename: basename(upload.originalName).slice(0, 255),
          sourceObjectPath: upload.objectPath,
          sourceSizeBytes: actualSize,
          sourceDuration: null,
          sourceWidth: null,
          sourceHeight: null,
          errorMessage: null,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(projectsTable.id, project.id),
            eq(projectsTable.userId, userId),
          ),
        )
        .returning();
      if (updatedProject) {
        await tx
          .update(videoUploadsTable)
          .set({ projectId: project.id, confirmedAt: new Date() })
          .where(eq(videoUploadsTable.id, upload.id));
      }
      return [updatedProject];
    });
    if (!updated) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    if (project.sourceObjectPath && project.sourceObjectPath !== upload.objectPath) {
      try {
        const previousFile = await storage.getObjectEntityFile(
          project.sourceObjectPath,
        );
        await previousFile.delete({ ignoreNotFound: true });
      } catch (err) {
        req.log.warn({ err, projectId: project.id }, "Old source cleanup failed");
      }
      await db
        .delete(videoUploadsTable)
        .where(
          and(
            eq(videoUploadsTable.projectId, project.id),
            eq(videoUploadsTable.userId, userId),
            ne(videoUploadsTable.id, upload.id),
          ),
        );
    }
    res.json(ConfirmProjectUploadResponse.parse(projectResponse(updated)));
  },
);

router.get("/projects/:projectId/source", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = GetProjectSourceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid project id." });
    return;
  }
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(
      and(
        eq(projectsTable.id, params.data.projectId),
        eq(projectsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!project?.sourceObjectPath) {
    res.status(404).json({ error: "Source video not found." });
    return;
  }

  try {
    const file = await storage.getObjectEntityFile(project.sourceObjectPath);
    const canRead = await storage.canAccessObjectEntity({
      userId,
      objectFile: file,
      requestedPermission: ObjectPermission.READ,
    });
    if (!canRead) {
      res.status(404).json({ error: "Source video not found." });
      return;
    }
    const [metadata] = await file.getMetadata();
    const size = Number(metadata.size);
    if (!Number.isSafeInteger(size) || size <= 0) {
      res.status(404).json({ error: "Source video not found." });
      return;
    }
    const rangeHeader = req.headers.range;
    const contentType = String(metadata.contentType ?? "video/mp4");
    res.setHeader("Accept-Ranges", "bytes");
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Content-Disposition", "inline");
    if (rangeHeader) {
      const range = parseRange(rangeHeader, size);
      if (!range) {
        res.status(416).setHeader("Content-Range", `bytes */${size}`).end();
        return;
      }
      res
        .status(206)
        .setHeader("Content-Range", `bytes ${range.start}-${range.end}/${size}`)
        .setHeader("Content-Length", String(range.end - range.start + 1));
      file.createReadStream(range).pipe(res);
      return;
    }
    res.setHeader("Content-Length", String(size));
    file.createReadStream().pipe(res);
  } catch (err) {
    if (err instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Source video not found." });
      return;
    }
    req.log.error({ err, projectId: project.id }, "Source video stream failed");
    res.status(500).json({ error: "Could not stream the source video." });
  }
});

router.get(
  "/projects/:projectId/exports",
  async (req, res): Promise<void> => {
    const userId = requireUserId(req, res);
    if (!userId) return;
    const params = ListProjectExportsParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Invalid project id." });
      return;
    }
    const [project] = await db
      .select({ id: projectsTable.id })
      .from(projectsTable)
      .where(
        and(
          eq(projectsTable.id, params.data.projectId),
          eq(projectsTable.userId, userId),
        ),
      )
      .limit(1);
    if (!project) {
      res.status(404).json({ error: "Project not found." });
      return;
    }
    const exports = await db
      .select()
      .from(exportsTable)
      .where(
        and(
          eq(exportsTable.projectId, project.id),
          eq(exportsTable.userId, userId),
        ),
      )
      .orderBy(desc(exportsTable.createdAt));
    res.json(ListProjectExportsResponse.parse(exports.map(exportResponse)));
  },
);

router.post(
  "/projects/:projectId/exports",
  async (req, res): Promise<void> => {
    const userId = requireUserId(req, res);
    if (!userId) return;
    const params = CreateProjectExportParams.safeParse(req.params);
    const body = CreateProjectExportBody.safeParse(req.body);
    if (!params.success || !body.success) {
      res.status(400).json({ error: "Enter valid clip boundaries and format." });
      return;
    }
    const [project] = await db
      .select()
      .from(projectsTable)
      .where(
        and(
          eq(projectsTable.id, params.data.projectId),
          eq(projectsTable.userId, userId),
        ),
      )
      .limit(1);
    if (!project || project.status !== "ready" || project.sourceDuration === null) {
      res.status(404).json({ error: "A ready source video is required." });
      return;
    }
    const { startTime, endTime, aspectRatio } = body.data;
    if (
      startTime < 0 ||
      endTime <= startTime ||
      endTime > project.sourceDuration ||
      endTime - startTime > getMaxClipDurationSeconds()
    ) {
      res.status(400).json({
        error: `Choose a clip up to ${getMaxClipDurationSeconds()} seconds long within the source.`,
      });
      return;
    }
    const [videoExport] = await db
      .insert(exportsTable)
      .values({
        projectId: project.id,
        userId,
        startTime,
        endTime,
        aspectRatio,
        status: "queued",
        progress: 0,
      })
      .returning();
    res
      .status(202)
      .json(CreateProjectExportResponse.parse(exportResponse(videoExport)));
  },
);

router.get("/exports/:exportId", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = GetExportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid export id." });
    return;
  }
  const [videoExport] = await db
    .select()
    .from(exportsTable)
    .where(
      and(
        eq(exportsTable.id, params.data.exportId),
        eq(exportsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!videoExport) {
    res.status(404).json({ error: "Export not found." });
    return;
  }
  res.json(GetExportResponse.parse(exportResponse(videoExport)));
});

router.get("/exports/:exportId/download", async (req, res): Promise<void> => {
  const userId = requireUserId(req, res);
  if (!userId) return;
  const params = DownloadExportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid export id." });
    return;
  }
  const [videoExport] = await db
    .select()
    .from(exportsTable)
    .where(
      and(
        eq(exportsTable.id, params.data.exportId),
        eq(exportsTable.userId, userId),
      ),
    )
    .limit(1);
  if (!videoExport || videoExport.status !== "completed" || !videoExport.outputObjectPath) {
    res.status(404).json({ error: "Completed export not found." });
    return;
  }
  res.redirect(
    302,
    `/api/storage/objects/${videoExport.outputObjectPath.slice("/objects/".length)}`,
  );
});

export default router;
