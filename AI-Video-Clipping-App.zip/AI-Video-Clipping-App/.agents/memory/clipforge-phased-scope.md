---
name: Clipforge phased scope
description: The agreed delivery boundary between the initial editor and later AI clipping features.
---

The initial Clipforge phase is a working manual editor: authenticated video upload, source inspection, playback, trim controls, FFmpeg MP4 rendering, and download. AI transcription and automatic clip suggestions are deferred.

**Why:** The master brief is broader than the first functional delivery, and the user approved building the real upload-to-export foundation before adding AI features.

**How to apply:** Keep this phase functional and avoid presenting mock AI capabilities as implemented. Treat transcription and clip suggestions as follow-up scope.
