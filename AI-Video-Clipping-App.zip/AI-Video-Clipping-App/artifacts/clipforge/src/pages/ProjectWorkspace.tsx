import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useLocation, useParams } from 'wouter';
import {
  getDownloadExportQueryKey, getGetDashboardSummaryQueryKey, getGetExportQueryKey, getGetProjectQueryKey,
  getListProjectExportsQueryKey, getListProjectsQueryKey, useCreateProjectExport,
  useConfirmProjectUpload, useDeleteProject, useDownloadExport, useGetExport, useGetProject,
  useListProjectExports, useUpdateProject,
  useRequestUploadUrl,
} from '@workspace/api-client-react';
import type { VideoExport, VideoExportAspectRatio } from '@workspace/api-client-react';
import WorkspaceShell from '@/components/WorkspaceShell';
import { getVideoContentType, uploadVideoWithProgress } from '@/lib/uploadVideo';
import {
  ArrowLeft, Check, ChevronDown, CircleAlert, Clapperboard, Clock3, Download,
  FileVideo2, LoaderCircle, Play, RefreshCw, RotateCcw,
  Scissors, Trash2, X,
} from 'lucide-react';

const RATIOS: { value: VideoExportAspectRatio; name: string; short: string }[] = [
  { value: '9:16', name: 'Vertical', short: '9:16' },
  { value: '1:1', name: 'Square', short: '1:1' },
  { value: '4:5', name: 'Portrait', short: '4:5' },
  { value: '16:9', name: 'Landscape', short: '16:9' },
];
const MAX_CLIP_SECONDS = 180;

function getErrorMessage(error: unknown) {
  if (error && typeof error === 'object' && 'message' in error) return String(error.message);
  return 'Something went wrong. Please try again.';
}

function formatTime(value: number | null | undefined) {
  if (value === null || value === undefined || !Number.isFinite(value)) return '00:00.00';
  const minutes = Math.floor(value / 60);
  const seconds = value - minutes * 60;
  return `${String(minutes).padStart(2, '0')}:${seconds.toFixed(2).padStart(5, '0')}`;
}

function formatLongTime(value: number | null) {
  if (value === null) return 'Duration unavailable';
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60);
  const hours = Math.floor(minutes / 60);
  return hours ? `${hours}:${String(minutes % 60).padStart(2, '0')}:${String(seconds).padStart(2, '0')}` : `${minutes}:${String(seconds).padStart(2, '0')}`;
}

function formatBytes(bytes: number | null) {
  if (bytes === null) return '—';
  return bytes >= 1_000_000_000 ? `${(bytes / 1_000_000_000).toFixed(2)} GB` : `${(bytes / 1_000_000).toFixed(1)} MB`;
}

function StatusTag({ status }: { status: VideoExport['status'] }) {
  const text = status === 'completed' ? 'Complete' : status === 'failed' ? 'Failed' : status === 'processing' ? 'Rendering' : 'Queued';
  return <span className={`status-pill export-status-${status}`}><span className="status-dot" />{text}</span>;
}

function ExportHistoryRow({ item }: { item: VideoExport }) {
  const [downloadActive, setDownloadActive] = useState(false);
  const exportQuery = useGetExport(item.id, {
    request: { credentials: 'include' },
    query: {
      queryKey: getGetExportQueryKey(item.id),
      refetchInterval: (query) => {
        const status = query.state.data?.status;
        return status === 'queued' || status === 'processing' ? 2500 : false;
      },
    },
  });
  const current = exportQuery.data ?? item;
  const downloadQuery = useDownloadExport(item.id, {
    request: { credentials: 'include' },
    query: { queryKey: getDownloadExportQueryKey(item.id), enabled: downloadActive, retry: false },
  });

  useEffect(() => {
    const blob = downloadQuery.data;
    if (!blob || !downloadActive) return;
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = `clip-${item.id}.mp4`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    setDownloadActive(false);
  }, [downloadQuery.data, downloadActive, item.id]);

  useEffect(() => {
    if (downloadQuery.isError) setDownloadActive(false);
  }, [downloadQuery.isError]);

  const duration = Math.max(0, current.endTime - current.startTime);
  return (
    <div className="export-row" data-testid={`row-export-${item.id}`}>
      <div className="export-icon"><Scissors size={16} /></div>
      <div className="export-main"><strong>Clip · {formatTime(current.startTime)} – {formatTime(current.endTime)}</strong><span>{duration.toFixed(1)} sec · {current.aspectRatio} · {new Date(current.createdAt).toLocaleString()}</span></div>
      <StatusTag status={current.status} />
      <div className="export-progress-cell">
        {(current.status === 'queued' || current.status === 'processing') ? <><div className="progress-track"><span style={{ width: `${Math.max(2, Math.min(100, current.progress))}%` }} /></div><span>{current.status === 'queued' ? 'Waiting' : `${current.progress}%`}</span></> : current.status === 'completed' ? <Check size={15} className="success-mark" /> : <span className="failed-note" title={current.errorMessage || undefined}>Needs attention</span>}
      </div>
      {current.status === 'completed' ? (
        <button className="icon-button export-download" aria-label="Download completed video" onClick={() => { setDownloadActive(true); void downloadQuery.refetch(); }} disabled={downloadQuery.isFetching} title={downloadQuery.isError ? getErrorMessage(downloadQuery.error) : 'Download MP4'} data-testid={`button-download-${item.id}`}>
          {downloadQuery.isFetching ? <LoaderCircle size={16} className="spin" /> : <Download size={16} />}
        </button>
      ) : <span className="export-row-spacer" />}
    </div>
  );
}

export default function ProjectWorkspace() {
  const { projectId = '' } = useParams<{ projectId: string }>();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const projectQuery = useGetProject(projectId, {
    request: { credentials: 'include' },
    query: {
      queryKey: getGetProjectQueryKey(projectId),
      enabled: Boolean(projectId),
      refetchInterval: (query) => {
        const status = query.state.data?.status;
        return status === 'inspecting' || status === 'processing' ? 1800 : false;
      },
    },
  });
  const exportsQuery = useListProjectExports(projectId, {
    request: { credentials: 'include' },
    query: {
      queryKey: getListProjectExportsQueryKey(projectId),
      enabled: Boolean(projectId),
      refetchInterval: (query) => query.state.data?.some((entry) => entry.status === 'queued' || entry.status === 'processing') ? 3000 : false,
    },
  });
  const createExport = useCreateProjectExport({ request: { credentials: 'include' } });
  const updateProject = useUpdateProject({ request: { credentials: 'include' } });
  const deleteProject = useDeleteProject({ request: { credentials: 'include' } });
  const requestUploadUrl = useRequestUploadUrl({ request: { credentials: 'include' } });
  const confirmUpload = useConfirmProjectUpload({ request: { credentials: 'include' } });
  const project = projectQuery.data;
  const totalDuration = Math.max(project?.sourceDuration ?? 0, 0);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const [aspectRatio, setAspectRatio] = useState<VideoExportAspectRatio>('9:16');
  const [title, setTitle] = useState('');
  const [editingTitle, setEditingTitle] = useState(false);
  const [actionError, setActionError] = useState('');
  const [sourceUploadError, setSourceUploadError] = useState('');
  const [sourceUploadProgress, setSourceUploadProgress] = useState<number | null>(null);
  const sourceFileInput = useRef<HTMLInputElement>(null);
  const sourceVideoRef = useRef<HTMLVideoElement>(null);
  const [justSaved, setJustSaved] = useState(false);
  const clipDuration = Math.max(0, endTime - startTime);
  const canRender = Boolean(project?.status === 'ready' && clipDuration > 0 && clipDuration <= MAX_CLIP_SECONDS && endTime <= totalDuration);
  const isUploadingSource = requestUploadUrl.isPending || confirmUpload.isPending || sourceUploadProgress !== null;
  const currentExport = useMemo(() => (exportsQuery.data ?? []).find((entry) => entry.status === 'processing' || entry.status === 'queued'), [exportsQuery.data]);

  useEffect(() => {
    if (project) {
      setTitle(project.title);
      setEndTime(Math.min(project.sourceDuration ?? 0, MAX_CLIP_SECONDS));
    }
  }, [project?.id, project?.sourceDuration]);

  async function renderClip(event: FormEvent) {
    event.preventDefault();
    if (!canRender) return;
    setActionError('');
    try {
      await createExport.mutateAsync({
        projectId,
        data: { startTime, endTime, aspectRatio },
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListProjectExportsQueryKey(projectId) }),
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
      ]);
    } catch (error) {
      setActionError(getErrorMessage(error));
    }
  }

  async function saveTitle(event: FormEvent) {
    event.preventDefault();
    if (!title.trim() || title.trim() === project?.title) { setEditingTitle(false); return; }
    try {
      await updateProject.mutateAsync({ projectId, data: { title: title.trim() } });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) }),
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
      ]);
      setEditingTitle(false);
      setJustSaved(true);
      window.setTimeout(() => setJustSaved(false), 1800);
    } catch (error) {
      setActionError(getErrorMessage(error));
    }
  }

  async function removeProject() {
    if (!window.confirm(`Delete “${project?.title}” and all of its exports? This cannot be undone.`)) return;
    try {
      await deleteProject.mutateAsync({ projectId });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
      ]);
      navigate('/');
    } catch (error) {
      setActionError(getErrorMessage(error));
    }
  }

  async function replaceSource(file: File) {
    const contentType = getVideoContentType(file);
    if (!contentType) {
      setSourceUploadError('Choose an MP4 or MOV video file.');
      return;
    }
    setSourceUploadError('');
    setSourceUploadProgress(0);
    try {
      const signed = await requestUploadUrl.mutateAsync({
        data: { name: file.name, size: file.size, contentType },
      });
      await uploadVideoWithProgress(
        signed.uploadURL,
        file,
        contentType,
        setSourceUploadProgress,
      );
      await confirmUpload.mutateAsync({
        projectId,
        data: { name: file.name, size: file.size, contentType, objectPath: signed.objectPath },
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) }),
        queryClient.invalidateQueries({ queryKey: getListProjectsQueryKey() }),
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
      ]);
      setSourceUploadProgress(null);
    } catch (error) {
      setSourceUploadError(getErrorMessage(error));
      setSourceUploadProgress(null);
    }
  }

  if (projectQuery.isLoading) return <WorkspaceShell><div className="workspace-loading"><div className="skeleton loading-title" /><div className="skeleton loading-preview" /><div className="skeleton loading-panel" /></div></WorkspaceShell>;
  if (projectQuery.isError || !project) return (
    <WorkspaceShell><div className="page-content"><Link href="/" className="back-link"><ArrowLeft size={15} /> All projects</Link><div className="state-card state-error workspace-error"><div className="state-icon error-icon"><CircleAlert size={19} /></div><h3>Project unavailable</h3><p>{projectQuery.isError ? getErrorMessage(projectQuery.error) : 'This project could not be found in your workspace.'}</p><button className="button button-secondary" onClick={() => projectQuery.refetch()} data-testid="button-retry-project"><RefreshCw size={15} /> Retry</button></div></div></WorkspaceShell>
  );

  return (
    <WorkspaceShell>
      <div className="workspace-page">
        <div className="workspace-topline">
          <Link href="/" className="back-link" data-testid="link-back-projects"><ArrowLeft size={15} /> Projects</Link>
          <div className="workspace-top-actions">
            <span className={`project-top-status ${project.status}`}><span className="status-dot" />{project.status === 'ready' ? 'Source ready' : project.status === 'failed' ? 'Source failed' : project.status === 'inspecting' || project.status === 'processing' ? 'Inspecting source' : 'Awaiting source'}</span>
            <button className="icon-button danger-hover" aria-label="Delete project" title="Delete project" onClick={removeProject} disabled={deleteProject.isPending} data-testid="button-delete-project"><Trash2 size={16} /></button>
          </div>
        </div>
        <header className="workspace-heading">
          <div className="workspace-title-area">
            {editingTitle ? (
              <form className="rename-form" onSubmit={saveTitle}><input autoFocus value={title} onChange={(event) => setTitle(event.target.value)} maxLength={160} aria-label="Project title" data-testid="input-rename-project" /><button className="icon-button save-icon" aria-label="Save project name" type="submit" disabled={updateProject.isPending} data-testid="button-save-project-name"><Check size={16} /></button><button className="icon-button" aria-label="Cancel rename" type="button" onClick={() => { setTitle(project.title); setEditingTitle(false); }} data-testid="button-cancel-rename"><X size={16} /></button></form>
            ) : (
              <button className="workspace-title-button" onClick={() => setEditingTitle(true)} title="Rename project" data-testid="button-rename-project"><h1>{project.title}<span className="heading-period">.</span></h1><span className="rename-cue">Rename</span></button>
            )}
            <div className="workspace-meta"><span><FileVideo2 size={14} />{project.sourceFilename || 'Source not attached'}</span><span><Clock3 size={14} />{formatLongTime(project.sourceDuration)}</span><span>{project.sourceWidth && project.sourceHeight ? `${project.sourceWidth} × ${project.sourceHeight}` : 'Resolution pending'}</span><span>{formatBytes(project.sourceSizeBytes)}</span></div>
            {justSaved && <span className="saved-feedback"><Check size={13} /> Project name saved</span>}
          </div>
          <div className="workspace-title-ornament">CUT<br /><span>01</span></div>
        </header>

        {project.errorMessage && <div className="project-error" role="alert"><CircleAlert size={16} /><div><strong>Source needs attention</strong><span>{project.errorMessage}</span></div></div>}

        <div className="editor-grid">
          <section className="preview-column">
            <div className="panel-heading"><div><span className="panel-index">01</span><h2>Source preview</h2></div><span className="panel-heading-meta">{project.sourceWidth && project.sourceHeight ? `${project.sourceWidth} × ${project.sourceHeight}` : 'SOURCE MONITOR'}</span></div>
            <div className="preview-monitor">
              <div className="monitor-cross cross-tl" /><div className="monitor-cross cross-tr" /><div className="monitor-cross cross-bl" /><div className="monitor-cross cross-br" />
                {project.sourcePlaybackUrl && project.status !== 'failed' ? (
                  <video
                    ref={sourceVideoRef}
                    className="source-video"
                    src={project.sourcePlaybackUrl}
                    controls
                    preload="metadata"
                    aria-label={`Source video preview: ${project.sourceFilename || project.title}`}
                    onPlay={() => {
                      const video = sourceVideoRef.current;
                      if (video && (video.currentTime < startTime || video.currentTime >= endTime)) {
                        video.currentTime = startTime;
                      }
                    }}
                    onTimeUpdate={() => {
                      const video = sourceVideoRef.current;
                      if (video && !video.paused && endTime > startTime && video.currentTime >= endTime) {
                        video.pause();
                        video.currentTime = startTime;
                      }
                    }}
                  />
                ) : (
                  <div className="monitor-content">
                    <div className="monitor-film-icon"><FileVideo2 size={23} /></div>
                    <strong>{project.sourceFilename || 'No source video attached'}</strong>
                    <span>{project.status === 'failed' ? 'Upload did not complete' : 'Waiting for source upload'}</span>
                    {(project.status === 'awaiting_upload' || project.status === 'failed') && (
                      <>
                        <input ref={sourceFileInput} className="visually-hidden" type="file" accept="video/mp4,video/quicktime,.mp4,.mov" disabled={isUploadingSource} onChange={(event) => { const file = event.target.files?.[0]; if (file) void replaceSource(file); event.currentTarget.value = ''; }} data-testid="input-replace-source" />
                        <button className="button button-secondary source-upload-button" onClick={() => sourceFileInput.current?.click()} disabled={isUploadingSource} data-testid="button-retry-source-upload">
                          {isUploadingSource ? <><LoaderCircle size={14} className="spin" /> Uploading source{sourceUploadProgress !== null ? ` · ${sourceUploadProgress}%` : ''}</> : <><RefreshCw size={14} /> {project.sourceFilename ? 'Replace source video' : 'Upload source video'}</>}
                        </button>
                        {sourceUploadProgress !== null && <div className="source-upload-progress" role="status"><span style={{ width: `${sourceUploadProgress}%` }} /></div>}
                      </>
                    )}
                  </div>
                )}
                <div className="monitor-footer"><span><span className="monitor-led" />SOURCE STATUS</span><span>{project.status === 'ready' ? 'READY' : project.status === 'failed' ? 'FAILED' : project.status === 'inspecting' || project.status === 'processing' ? 'INSPECTING' : 'AWAITING UPLOAD'}</span></div>
            </div>
            {sourceUploadError && <div className="form-error source-upload-error" role="alert"><CircleAlert size={15} />{sourceUploadError}</div>}
            <div className="preview-notice"><CircleAlert size={14} /><span>{project.status === 'inspecting' || project.status === 'processing' ? 'Source inspection is running in the background. The preview is available while its duration and dimensions are checked.' : 'Preview playback is private to your account. Playback follows the selected trim range.'}</span></div>
            <section className="trim-panel">
              <div className="panel-heading trim-heading"><div><span className="panel-index">02</span><h2>Trim boundaries</h2></div><button className="text-button reset-trim" onClick={() => { setStartTime(0); setEndTime(Math.min(totalDuration, MAX_CLIP_SECONDS)); }} disabled={!totalDuration} data-testid="button-reset-trim"><RotateCcw size={13} /> Reset</button></div>
              {totalDuration > 0 ? (
                <>
                  <div className="timeline-ruler"><span>00:00</span><span>{formatLongTime(totalDuration / 2)}</span><span>{formatLongTime(totalDuration)}</span></div>
                  <div className="timeline-track" aria-label="Clip trim range">
                    <div className="timeline-unselected left" style={{ width: `${Math.max(0, Math.min(100, startTime / totalDuration * 100))}%` }} />
                    <div className="timeline-selected" style={{ left: `${Math.max(0, startTime / totalDuration * 100)}%`, width: `${Math.max(0, (endTime - startTime) / totalDuration * 100)}%` }} />
                    <div className="timeline-unselected right" style={{ width: `${Math.max(0, 100 - endTime / totalDuration * 100)}%` }} />
                    <input className="trim-range trim-start" type="range" min={0} max={Math.max(0, totalDuration - 0.1)} step="0.1" value={startTime} onChange={(event) => setStartTime(Math.min(Number(event.target.value), endTime - 0.1))} aria-label="Clip start boundary" data-testid="range-trim-start" />
                     <input className="trim-range trim-end" type="range" min={0} max={Math.min(totalDuration, startTime + MAX_CLIP_SECONDS)} step="0.1" value={endTime} onChange={(event) => setEndTime(Math.max(startTime + 0.1, Math.min(Number(event.target.value), totalDuration, startTime + MAX_CLIP_SECONDS)))} aria-label="Clip end boundary" data-testid="range-trim-end" />
                  </div>
                  <div className="time-inputs">
                    <label><span>IN</span><input type="number" min="0" max={Math.max(0, endTime - 0.1)} step="0.1" value={startTime.toFixed(1)} onChange={(event) => setStartTime(Math.max(0, Math.min(Number(event.target.value), endTime - 0.1)))} data-testid="input-trim-start" /><i>SEC</i></label>
                    <span className="time-separator">TO</span>
                     <label><span>OUT</span><input type="number" min={startTime + 0.1} max={Math.min(totalDuration, startTime + MAX_CLIP_SECONDS)} step="0.1" value={endTime.toFixed(1)} onChange={(event) => setEndTime(Math.max(startTime + 0.1, Math.min(Number(event.target.value), totalDuration, startTime + MAX_CLIP_SECONDS)))} data-testid="input-trim-end" /><i>SEC</i></label>
                    <span className="duration-chip">{Math.max(0, endTime - startTime).toFixed(1)} sec selected</span>
                  </div>
                </>
              ) : (
                <div className="no-duration"><Clock3 size={16} /><span>Trim controls unlock when the source duration is available.</span></div>
              )}
            </section>
          </section>

          <aside className="settings-column">
            <form className="settings-panel" onSubmit={renderClip}>
              <div className="panel-heading"><div><span className="panel-index">03</span><h2>Export setup</h2></div><Clapperboard size={16} className="panel-heading-icon" /></div>
              <div className="setting-block">
                <div className="setting-title"><span>FRAME</span><small>Choose your destination shape</small></div>
                <div className="ratio-list">
                  {RATIOS.map((ratio) => (
                    <button type="button" key={ratio.value} className={`ratio-option ${aspectRatio === ratio.value ? 'selected' : ''}`} onClick={() => setAspectRatio(ratio.value)} data-testid={`button-ratio-${ratio.value.replace(':', '-')}`}>
                      <span className={`ratio-glyph ratio-${ratio.value.replace(':', '-')}`}><i /></span><span>{ratio.name}</span><small>{ratio.short}</small>{aspectRatio === ratio.value && <Check size={13} className="ratio-check" />}
                    </button>
                  ))}
                </div>
              </div>
              <div className="export-summary">
                <div><span>Selected range</span><strong>{formatTime(startTime)} — {formatTime(endTime)}</strong></div>
                <div><span>Clip length</span><strong>{Math.max(0, endTime - startTime).toFixed(1)} sec</strong></div>
                <div><span>Output</span><strong>MP4 · {aspectRatio}</strong></div>
              </div>
              {actionError && <div className="form-error" role="alert"><CircleAlert size={15} />{actionError}</div>}
              <button className="button button-primary render-button" type="submit" disabled={!canRender || createExport.isPending} data-testid="button-render-clip">
                {createExport.isPending ? <><LoaderCircle size={16} className="spin" /> Queueing render</> : <><Play size={15} fill="currentColor" /> Render clip</>}
                {!createExport.isPending && <span className="button-arrow">↗</span>}
              </button>
              {!project.sourceDuration && <p className="render-note">Source duration is required before a render can be queued.</p>}
              {project.status !== 'ready' && project.sourceDuration ? <p className="render-note">A ready source is required before a render can be queued.</p> : null}
              {project.status === 'ready' && project.sourceDuration && clipDuration > MAX_CLIP_SECONDS ? <p className="render-note">Choose a clip up to {MAX_CLIP_SECONDS} seconds long.</p> : null}
              {project.status === 'ready' && project.sourceDuration && clipDuration <= MAX_CLIP_SECONDS && !canRender ? <p className="render-note">Choose a valid range within the source duration.</p> : null}
            </form>
            <div className="queue-card">
              <div className="queue-card-top"><span className="eyebrow">RENDER QUEUE</span><span className={`queue-live ${currentExport ? 'queue-active' : ''}`}><i />{currentExport ? 'ACTIVE' : 'IDLE'}</span></div>
              {currentExport ? <div className="queue-current"><div className="queue-spinner"><LoaderCircle size={17} className="spin" /></div><div><strong>{currentExport.status === 'queued' ? 'Waiting for a render slot' : 'Your clip is rendering'}</strong><span>Progress updates automatically</span></div></div> : <div className="queue-idle"><span>No render in progress.</span><span>Queue a clip when your boundaries are set.</span></div>}
            </div>
            <div className="source-details"><div className="source-details-heading">SOURCE DETAILS <ChevronDown size={13} /></div><div><span>File size</span><strong>{formatBytes(project.sourceSizeBytes)}</strong></div><div><span>Added</span><strong>{new Date(project.createdAt).toLocaleDateString()}</strong></div></div>
          </aside>
        </div>

        <section className="history-section">
          <div className="section-heading"><div><div className="eyebrow section-eyebrow">OUTPUTS</div><h2>Export history</h2></div><span className="section-count">{exportsQuery.isLoading ? '—' : `${exportsQuery.data?.length ?? 0} ${exportsQuery.data?.length === 1 ? 'render' : 'renders'}`}</span></div>
          {exportsQuery.isLoading ? <div className="history-loading">{[0, 1].map((n) => <div className="skeleton history-skeleton" key={n} />)}</div> : exportsQuery.isError ? (
            <div className="history-error"><CircleAlert size={16} /><span>Export history could not be loaded.</span><button className="text-button" onClick={() => exportsQuery.refetch()} data-testid="button-retry-exports">Retry</button></div>
          ) : exportsQuery.data?.length ? (
            <div className="export-list">{exportsQuery.data.map((item) => <ExportHistoryRow item={item} key={item.id} />)}</div>
          ) : (
            <div className="history-empty"><span className="history-empty-symbol"><Scissors size={17} /></span><div><strong>No exports yet</strong><span>Set your in and out points, then render your first clip.</span></div><span className="history-empty-index">A / 00</span></div>
          )}
        </section>
      </div>
    </WorkspaceShell>
  );
}
